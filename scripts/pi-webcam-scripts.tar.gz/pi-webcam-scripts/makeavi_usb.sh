#!/bin/bash

DATE=$(date +"%Y-%m-%d-%H-%M")

cd /mnt/hd1/webcam

cat $(ls | sort -V) | ffmpeg -framerate 10 -i - -vcodec libx264 -pix_fmt yuv420p -r 20 $DATE.avi

date
echo  video created from webcam images
echo moving video to videos directory

mv $DATE.avi /mnt/hd1/videos



