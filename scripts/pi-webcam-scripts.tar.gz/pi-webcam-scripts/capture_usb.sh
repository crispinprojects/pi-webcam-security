#!/bin/bash

DATE=$(date +"%Y-%m-%d-%H-%M")

fswebcam -r 640x480 -S 10 -F 16 /mnt/hd1/webcam/$DATE.jpg
