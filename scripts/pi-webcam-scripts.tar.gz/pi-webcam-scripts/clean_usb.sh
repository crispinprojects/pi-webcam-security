#!/bin/bash

echo removing webcam images
date

rm -rf /mnt/hd1/webcam/*
